# 赛季挑战 · UMG UI 工程

《三角洲行动》赛季任务页面复刻，UE **5.8.4**，运行逻辑为 Widget Blueprint。适用于 Windows 编辑器评审。

## 打开与运行

1. 将压缩包完整解压到可写的本地目录。
2. 用 UE 5.8.4 打开 `SeasonChallenge.uproject`。首次打开会生成本地缓存。
3. 默认地图为 `/Game/UI/Data/L_SeasonChallenge`，点击 Play 或选择独立运行。
4. 参考窗口：标准 2560×1440、平板 2560×1792、宽屏 3100×1440。按实际宽高比自动切换布局。

无需安装第三方插件、Python 或额外字体。工程中没有 C++ 模块。

## 建议评审路径

- 界面入口：`/Game/UI/Widgets/WBP_SeasonChallengeScreen`。
- 公共交互：`WBP_InteractiveBase` → `WBP_TaskCard` / `WBP_NavItem`。
- 奖励与条件：`WBP_StageReward`、`RefreshStageConditions`、`WBP_ObjectiveEntry`。
- 行动阶段：`WBP_ActionPlanContent` 和 `WBP_ActionStageSegment`。
- 配置入口：`/Game/UI/Styles` 的 `DA_` 实例，以及 `/Game/UI/Data` 的阶段、目标和中英日 String Table。
- `Docs` 中提供蓝图、函数、变量和节点对比表，以及验证摘要；三种分辨率截图在学习网站中查看。

## 可验证交互

- 导航悬浮高亮，点击显示绿色底板与上下绿线；三个导航互斥选中。
- 三张任务卡悬浮时仅背景图放大到 1.2 倍，图片裁剪在卡片内；点击显示四周白边。
- 奖励左右切换，不首尾循环；首端/末端对应箭头隐藏但保留位置。奖励、标题、分页和达成条件同步更新，快速连点有保护。
- 行动计划阶段按进度自动更新；收集者与契约显示完成数和状态。条件列表支持内容超出后滚动。
- 返回箭头保留鼠标反馈，不离开页面。

## 蓝图整理

本版保留 19 个可复用 Widget Blueprint。共整理 42 个蓝图资产，逻辑节点 **3844 → 3496**，减少 **348** 个冗余节点。

函数包含用途、输入输出和副作用说明；节点包含中文注释，事件和计算分区有注释框。执行连接、默认值、阶段数据和动画绑定经过等价检查。继承公共交互逻辑，不为减少数量破坏组件接口。

保留原有布局和视觉标定；最大容器深度为 3，没有 Overlay、Widget Switcher 或 Tick 动画插值。条件列表使用 ListView 虚拟化，三个固定异形入口卡各用同一可复用卡片类；材质实例共用 2 个。

## 工程内容

- `Content/UI`：Widgets / Data / Styles / Textures / Materials / Fonts。
- `SourceArt/Textures`：网站单独提供可选重导入源包，解压到本工程根目录；不影响运行。
- `Fonts` 内为已内嵌字体资源，无需访问作者机器上的字体文件；若需要重新导入字体，可在字体资源中另行指定源文件。
- `Config`：默认地图、UI DPI 和本地缓存配置。
- `Docs`：评审导读、参数入口、清单与验证摘要。

压缩包不包含缓存、日志、自动保存、测试工程、作者工具脚本或引擎文件。

## 演示范围

任务进度和奖励为本地演示数据，不连接游戏服务端。字体使用已确认的思源系黑体替代 ProjectD；资源保持当前确认的视觉版本。本包是工程源码交付，需通过 UE 编辑器运行。
